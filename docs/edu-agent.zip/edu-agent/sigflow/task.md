# SigFlow 教育版 Agent：SigFlow 组执行任务清单

> 版本：v1.0 · 2026-09-24  
> 依据：[SigFlow 组 spec](spec.md)；跨组接口与交付参照 [UCAgent 组 spec](../ucagent/spec.md) 和 [Cooperate.md](../Cooperate.md)。  
> 范围：仅 SigFlow 教育版侧；3 人（S1 接口/运行时、S2 数据/EDA、S3 UI/集成），10 周。W1 从实际开工日算起，尚未映射到日历日期。  
> 状态：`[ ]` 待做、`[~]` 进行中、`[x]` 完成且验收证据已归档、`[!]` 阻塞。本文创建时新增任务全部为 `[ ]`。  
> 估算：每人 40 计划人日 + 10 缓冲人日，全组 120 计划人日 + 30 缓冲人日；W2 根据真实联调吞吐重估。

## 0. 使用和完成规则

本文件是执行清单，不表示实现已经开始。每项任务完成时，负责人同时补充 PR/commit、测试命令及结果、演示或截图、相关契约版本，再把 `[ ]` 改为 `[x]`。只改代码未验证仍为 `[~]`。阻塞项标 `[!]`，写明阻塞方、需要的输入、临时 Mock 方案及下次检查日期。

各任务均遵守 [共享 HTTP 契约](spec.md#5-共享-http-契约-v1两组共同执行)。机器可读 `contracts/edu-agent/v1/` 在 W1 创建后是字段真源；本文件的路由、名称与阈值不得私自漂移。若需要改变接口，S1/U1 同时修改 schema、fixture、两个客户端/服务端测试及决策记录。

**不在本期重复做**：工具链插件化总重构、CMake/平台移植总工程、工程版 Agent、完整 eda-ir 拆包、自动改学生代码、Agent 调用布线/打包/烧录、任意 shell 或文件系统桥。跨平台 **集成验证与打包** 仍是本期任务。

### 0.1 当前代码基线：复用，不算完成本清单

| 现有资产 | 已核对位置 | 本期接入差距 |
|---|---|---|
| 核心 Job/插件 | `include/eda/api/jobs.hpp`、`core/src/eda-core/JobService.*`、`main/Composer.*`、`InnerPlugin/eda-*` | Gateway/授权/恢复/报告适配尚无；GUI 综合与布线仍有 legacy 与可选新路径 |
| 报告 | `core/src/eda-core/CoreSchemas.cpp`、`main/jobs/schemas/job-report.schema.json` | 新 `diagnostics` 当前是 JSON 对象，不能直接当规范化 `Diagnostic[]`；新旧 schema 不同 |
| Job 存储 | `core/src/eda-core/JobService.cpp` | 默认根目录为临时 `sigflow-jobs`；`records_`/`reports_` 为内存表，无重启加载；需要安全的持久化边界与恢复策略 |
| 工程与图码 | `core/src/eda-core/Project.*`、`main/SigTree.*`、`main/VerilogManager.*` | 建立 revision/snapshot、线程安全只读 DTO、可靠局部映射 |
| 波形 | `include/eda/api/waveform.hpp`、`main/trace/TraceQueryService.*`、`main/wave/WaveformView.*` | artifact 归属、精确查询/分页、GUI 选择窗与卡片定位 |
| 构建与版本 | `CMakeLists.txt` 的 `SIGFLOW_EDITION`，`docs/BUILD.md` | 新 Agent 装配开关和实际两平台/既有麒麟目标回归 |

以上为静态源码核对；历史进展文档里的测试结果不视为本期验收。W1 建立当前可复现构建/测试基线。仓库已有的其他未提交文档不纳入本任务的清理或改写。

### 0.2 新增代码落点（待创建，W1 可调整命名）

| 位置 | 归属 |
|---|---|
| `contracts/edu-agent/v1/` | 双方共用 OpenAPI、JSON Schema、fixtures、变更记录 |
| `core/src/eda-agent-gateway/` | SigFlow HTTP Gateway、鉴权、事件、幂等、授权和纯数据 DTO |
| `main/agent/` | sidecar 控制器、UI 上下文桥、报告/快照适配、教学面板与卡片 |
| `tests/agent/` + `tests/contract/` | Gateway/边界/GUI 辅助测试及双方契约 fixtures |
| `examples/edu_agent/` | 锁存器、计数器复位等可复现小实验、预期与运行说明 |

后端数据逻辑可在实现时下沉 `core`，但 wx 控件访问须留在主线程。保持 `MainFrame` 只承担入口装配/事件路由，避免把 HTTP 服务器和教学规则堆进去。任何新文件加入 CMake 显式源列表并由相关测试 target 编译。

## 1. 先锁定的决策与依赖

### D-01 开工日与可复现基线｜S1 主责，S2/S3 配合｜W1 D1–D2

- [ ] 记录 W1 的实际起止日期、三位 SigFlow 成员与 U1/U2/U3 对应人；给各工作包指定唯一负责人和替补。
- [ ] 在未改造 Agent 的干净构建配置下记录 Windows 与 Linux 的构建命令、编译器、wx/HTTP 依赖、工具链插件版本、`ctest` 结果及已知失败。麒麟只列团队实际完成的 OS/架构，不推定 ARM64/LoongArch 已可发布。
- [ ] 核查当前 `SIGFLOW_EDITION=edu`、`SIGFLOW_USE_JOB_SERVICE`、三类目标插件（sim.build、sim.run、synth）的运行状态和本机工具路径；形成 `docs/edu-agent/sigflow/baseline.md`（计划产物）。
- [ ] 确定两份基础样例：锁存器正例与合法锁存器反例、计数器复位波形例；记录真实 RTL、期望诊断/波形、工具版本、运行步骤。U2/U3 对教学期望签核。

**完成证据**：基线记录含环境、命令、结果和可复现样例；失败项有责任/修复计划。**依赖**：无。**影响 Gate**：G0。

### D-02 接口与部署决定｜S1/U1 联合｜W1 D1–D3

- [ ] 固定 `/api/v1`、双本地 HTTP 服务、两个独立 token、实例 ID、随机端口、长轮询事件、错误信封与主版本兼容规则；明确 UI 专用 grant/receipt 通道的凭据与信任边界。
- [ ] 用 MinGW Windows/Linux 最小样例验证候选 C++ HTTP 库的许可证、编译、停止、超时、loopback bind；记录选型。Python 库由 U1 自行锁定，双方只共享线上协议。
- [ ] 与 U1 定义 `SourceRef`、`EvidenceRef`、`Diagnostic`、`JobReportView`、`PlanCard`、`TeachingCard`、`Event` 的必填/可空/枚举/版本语义；确定 64 位 tick/uid 用十进制字符串。
- [ ] 写 `contracts/edu-agent/v1/{sigflow.openapi.yaml,agent.openapi.yaml,schemas/,fixtures/}` 第一版；S1 负责 SigFlow 路由和共有 DTO，U1 负责 Agent 路由。双方互签变更记录。
- [ ] 定义共享 fixtures：健康/不兼容版本、能力可用/缺失、新旧 Job 报告、dirty/旧 revision、已授权/未授权 Job、波形边界、事件恢复、L4 两步与过期凭据。

**完成证据**：双方 Mock 按同一套 schema/fixtures 通过，W2 前冻结 v1 最小字段。**依赖**：D-01。**影响 Gate**：G0–G4。

### D-03 产品/数据边界｜S1/S2/S3 联合｜W1

- [ ] 冻结一期 Agent 能力白名单：`eda.sim.build`、`eda.sim.run`、`eda.synth`；`eda.pnr/pack/flash/debug` 返回 disabled/reason，不能通过通用插件调用绕过。
- [ ] 冻结“已保存且同步完成的版本才能跑 EDA”策略；未保存编辑缓冲可供只读解释但必须标 `dirty`/buffer hash，旧磁盘 Job 不可冒充当前代码结果。
- [ ] 冻结快照保留、报告归一化和学习数据库的数据所有权：SigFlow 写快照/Job/授权/审计；UCAgent 写学习记录/课程索引；不共写 SQLite。
- [ ] 确定 `SIGFLOW_BUILD_EDU_AGENT` 建议开关与 `agent.enabled/auto_prompt` 运行时开关的默认值、教育版可见入口及关闭后的现有体验；记录旧 DeepSeek 面板与教学提示并存规则。

**完成证据**：决策记录与正/负能力列表；S1/U1 对工具名映射一致。**依赖**：D-02。**影响 Gate**：G0。

## 2. 工作包概览与依赖图

| ID | 主责 | 计划人日 | 目标周 | 前置 | 交付摘要 |
|---|---|---:|---|---|---|
| SF-01 契约与握手 | S1 | 7 | W1–W2 | D-01/02 | schema、fixtures、双服务健康与启动握手 |
| SF-02 Gateway、权限、事件 | S1 | 12 | W2–W5 | SF-01 | 受限 HTTP、事件游标、幂等/凭据仓储 |
| SF-03 Job/授权/恢复 | S1 | 13 | W3–W7 | SF-02、SF-05/06 | 真实插件调度、取消、计划 grant 与重启核对 |
| SF-04 sidecar/发布 | S1 | 8 | W7–W10 | SF-01/02/03 | 生命周期、跨平台集成包、故障排查 |
| SF-05 快照与版本 | S2 | 10 | W1–W4 | D-03 | revision、保存边界、不可变输入 |
| SF-06 报告与诊断 | S2 | 11 | W1–W4 | D-02 | 新旧 JobReportView、来源/完整性 |
| SF-07 局部映射与上下文 | S2 | 9 | W4–W6 | SF-05 | 节点/RTL refs、同版本局部证据包 |
| SF-08 波形查询 | S2 | 10 | W5–W7 | SF-05/06 | artifact 波形精确查询与分页 |
| SF-09 教学面板与卡片 | S3 | 14 | W1–W5 | SF-01、U1 Mock | 会话/提示/计划/授权 UI |
| SF-10 四视图定位 | S3 | 10 | W5–W7 | SF-07/08 | 原理图、RTL、波形、报告互跳 |
| SF-11 历史/引用/提示 | S3 | 8 | W6–W9 | SF-09、U3 API | 学习记录/课程入口、主动提示与设置 |
| SF-12 回归与发布 | S3 | 8 | W8–W10 | 全部 P0 | GUI/安装/试用、用户文档 |

按人汇总：S1 40、S2 40、S3 40 计划人日。D-01/02/03 的工作时间包含在相应 SF-01、SF-05/06、SF-09 包内，不额外叠加。缓冲每人 10 人日用于跨组联调、缺陷及试用整改。

```mermaid
flowchart LR
  D[W1 决策与真实 fixture] --> C[SF-01 双方契约]
  C --> G[SF-02 Gateway]
  D --> V[SF-05 revision/快照]
  D --> R[SF-06 报告适配]
  V --> X[SF-07 局部上下文]
  V --> W[SF-08 波形]
  R --> J[SF-03 授权 Job]
  G --> J
  V --> J
  C --> UI[SF-09 教学面板]
  X --> LINK[SF-10 四视图]
  W --> LINK
  UI --> LINK
  J --> END[联合闭环与发布]
  LINK --> END
```

## 3. S1：HTTP、运行时与执行边界（40 人日）

### SF-01 契约与双服务握手｜7 人日｜W1–W2

- [ ] 将 D-02 的 Gateway 路由、DTO、错误码、限额、游标、成功/失败信封写入 OpenAPI/JSON Schema；锁定协议主版本 `v1` 和字段演化规则。
- [ ] 做 SigFlow 侧 DTO 序列化/反序列化与 schema 校验；错误字段不能包含 API Key、绝对路径、原始环境变量。
- [ ] 实现 `GET /health`、`GET /capabilities` 的最小 Gateway；能力来自真实插件/Job provider 的 ready 状态，缺失理由可读，不能只看插件文件存在。
- [ ] 与 U1 完成 UI→Agent、Agent→EDA 两方向 HTTP Mock：启动握手含 instance_id、随机 nonce、build/protocol；主版本不兼容禁用 Agent 并在 UI 显示状态。
- [ ] 建立契约测试入口与 golden fixtures，覆盖未知可选字段、未知枚举、空数组、超限请求、中文/空格路径、64 位 tick/uid。

**修改点**：`contracts/edu-agent/v1/`、拟建 `core/src/eda-agent-gateway/`、`tests/contract/`、CMake 显式源列表。**输出给 U1**：API schema、Mock URL/fixtures、版本兼容表。**完成条件**：不依赖模型和真实 Job 即可完成健康/能力/报告样例往返，双方契约 CI 一致；G0。

### SF-02 Gateway、鉴权、事件与幂等基础｜12 人日｜W2–W5

- [ ] HTTP server 仅绑定 `127.0.0.1` 随机端口；验证 Bearer token、Host/Origin、instance/project 所属；拒绝跨项目、未知路径和通用插件 `invoke` 请求。
- [ ] 建立 UI 专用控制能力与 Agent 客户端能力的授权表；`POST /projects/{p}/grants` 和 `POST /projects/{p}/ui-receipts` 仅 UI 可签发；Agent 仅能查询、核销属于该 session 的 receipt 或提交带有效 grant 的白名单 Job。
- [ ] 在 `<project>/.sigflow/agent/` 建持久化审计/幂等/授权索引；实际格式 W2 冻结。日志记录 trace_id、request_id、run/plan/grant/job、动作/结果/时间，不记录 Key 或过量源码。
- [ ] 实现写请求幂等：在调用 JobService 前原子登记 idempotency scope 和规范化请求 hash；相同键同内容返回同资源，键相同内容不同 409。断电于登记/提交交界时进入 `RECOVERY_REQUIRED`，查询确认后才允许人工恢复。
- [ ] 实现 receipt `issue→query→consume` 的一次性事务，绑定 challenge_id、session/issue/revision/policy、action_id/state_version；相同 action 的重复核销返回同一结果，其他动作重用 403/409。receipt 不进入模型上下文。
- [ ] 订阅项目/Job/产物/选择事件并封装 `Event{sequence,event_id,...}`；事件持久化或以可重建日志支撑至少一次投递和游标恢复。实现 `GET /projects/{p}/state` 一致性快照和 long poll。游标过期 410，UI/U1 先取 state+high_watermark 再续订。
- [ ] 实现边界限额：请求体 1 MiB、普通响应 2 MiB、集合默认 100/最多 500；事件 10,000 条或 24 小时保留，超限显式 429/分页。HTTP worker 不触碰 wx 对象。
- [ ] 故障测试：重复事件、并发相同幂等键、跨项目读写、过期/伪造 receipt、未知 Origin、服务关闭中请求、坏 JSON、端口占用。

**修改点**：拟建 Gateway 中 `Auth/Grant/Receipt/Idempotency/EventStore/HttpServer` 等模块、`tests/agent/`。**输出给 U1**：可信身份规则、错误码/恢复 fixture、事件游标样例。**完成条件**：同请求并发 20 次只进入一次真实 Job 前路径；未获 UI grant 无法调度；快照+游标可无漏恢复；SF-AC02。**依赖**：SF-01。

### SF-03 JobService 接线、执行授权与恢复｜13 人日｜W3–W7

- [ ] 在 Composer/Gateway 上建立 `eda.sim.build`、`eda.sim.run`、`eda.synth` 到已就绪 `IJobProvider::jobType` 的显式映射；按 provider 参数 schema 验证，剔除模型可控的任意可执行文件、工作目录、输出路径、脚本字段。`eda.pnr/pack/flash/debug` 返回 disabled。
- [ ] 将 Agent Job 数据根目录固定到项目受控目录或经认可的应用数据目录，记录 project/instance/owner，并兼容现有手动 Job 的查阅；不能继续依赖默认系统临时目录作为可恢复来源。
- [ ] 补 CoreJobService 或其包装层的提交前持久化与重启加载：manifest/报告原子写入、Job ID 唯一性、未知/运行中状态恢复。当前源码只把记录留在内存表，需明确 `submit`、崩溃、重启各阶段的行为。
- [ ] 将 plan_hash、快照指纹、capability/provider、参数、步骤、TTL、max_jobs 绑定 grant；每次执行前验证 revision、依赖 Job 和产物 hash。计划变化/超时/用户撤销时拒绝后续步骤。
- [ ] 保证同项目 Agent 与手动 Job 共用资源排队；Agent 计划每步最多 3 个 Job，失败/取消/超时/版本变更即停。Agent 网络重试沿用幂等键，不调用 CoreJobService 的普通 `retry()` 生成新 Job；学生明确重跑才新建 attempt 与授权。
- [ ] `sim.run` 只接受本计划成功 `sim.build` 登记的执行产物；snapshot 决定源文件/目标参数，Gateway 不接受 Agent 提供绝对路径；工具启动失败也有 Job/错误记录。
- [ ] 实现 `GET /jobs/{j}`、`/report`、`POST /jobs/{j}/cancel` 与按项目列表；取消只作用于该 run 的 Job，取消 ack 与真正进程退出分开显示。服务关闭、Agent 断开 30 秒后不启动后继步骤，已运行 Job 状态仍可查。
- [ ] 做真实 Yosys、Verilator 编译/运行与 Fake provider 故障注入：超时、取消进程树、失败码、产物丢失、重启、重复提交、两个项目并发。验证旧手动流程仍能用，不发生双投。

**修改点**：`main/Composer.*`、`core/src/eda-core/JobService.*` 或其受控包装、拟建 Gateway JobAdapter/Recovery、测试。**输出给 U1/U2**：真实 Job ID、状态/报告、计划执行限制和恢复状态 fixture。**完成条件**：EDU-01/04 中真实工具经插件运行；20 次重复请求仅 1 Job；重启后旧 Job 不重复执行；SF-AC02/04。**依赖**：SF-02、SF-05/06。

### SF-04 sidecar 生命周期、跨平台与发布｜8 人日｜W7–W10

- [ ] 由 IDE 管理每实例一个 Python sidecar：定位与版本检查、受限继承管道传启动材料、随机端口、ready nonce、健康探测、正常退出与最多 3 次退避重启；不同实例 token/数据目录隔离。
- [ ] 禁止 Key 出现在命令行、URL、工程文件、进程日志；令牌只在短期进程生命周期内使用，重启后轮换。新进程不得继承旧 grant 的自动执行权。
- [ ] sidecar 不可用时 UI 可继续旧编辑/仿真/综合；明确区分“未安装、启动失败、协议不兼容、无模型 Key、网络故障、Agent 崩溃”。
- [ ] Windows MinGW 与 Linux 原生安装/启动/关闭验证，覆盖中文与空格路径、端口冲突、双实例、升级/回退、Python 依赖缺失。麒麟按团队实际已交付 OS/架构复测并保存系统版本。
- [ ] 固定 C++ HTTP 依赖和 Python 包/sidecar 版本清单；构建开关、运行时配置、打包路径、许可证与升级迁移写入发布材料；U1 提供 Python 锁文件与依赖说明。
- [ ] 做性能和失效演练：UI p95 点击反馈目标 <100 ms，普通本地元数据 API p95 <300 ms；模型/EDA 耗时分开；关闭窗体后后台回调不访问已释放 UI。

**修改点**：拟建 `main/agent/AgentServiceController.*`、CMake/打包脚本、安装与故障文档。**输出给 U1**：进程启动约束、部署目录和日志格式。**完成条件**：两平台新装、故障、回退流程可重复；SF-AC08/09。**依赖**：SF-01/02/03，U1 的可安装 sidecar。

## 4. S2：工程数据、报告、上下文与波形（40 人日）

### SF-05 revision 与不可变工程快照｜10 人日｜W1–W4

- [ ] 定义 revision 变更源：RTL、工程配置、include、约束、图码同步结果、目标/工具策略；选择变化不改变设计 revision。为编辑缓冲记录 dirty/buffer hash，不能将磁盘旧版当当前代码。
- [ ] 建立 `project_id` 与 `source_id` 稳定生成规则、工程相对路径规范和允许的外部 include 列表；路径解析后检查工程/白名单根目录和符号链接，不允许 `..` 或别名越界读取。
- [ ] 实现 `GET /projects/{p}/context`、`GET /projects/{p}/state` 中的版本与源文件摘要；在只读解释情形返回编辑缓冲状态，结果标明是否可用于执行。
- [ ] 实现 `POST /projects/{p}/snapshots`：只接受 expected_revision 命中的、已保存且图码同步完成的状态；固定源文件/配置内容或 hash/目标/插件参数，记录 snapshot_id、revision、input_fingerprint。源文件在快照构建期间改变则失败并重试，不产生混合版本。
- [ ] 快照只提供已登记源文件和允许 include；不复制整个工程；快照完成后编辑原文件不影响 Job 输入。被活跃 Job/待批准计划引用时固定保留；其他按 spec 的最近 20 个或 7 天清理。
- [ ] 测试未保存/同步中、保存后立即再编辑、同名工程不同实例、外部 include、符号链接、目标配置变化、快照清理后请求返回 expired。

**修改点**：拟建 SnapshotService/ProjectRevision，现有 `main/VerilogManager.*`、`main/MainFrame.*` 的保存/同步入口只做必要接线。**输出给 U1/U2**：同版本 project/snapshot/source fixture。**完成条件**：旧卡不能跑新版本；Job 输入 hash 与保存版本一致；SF-AC03。**依赖**：D-03、SF-01 基础 DTO。

### SF-06 新旧报告归一化与诊断证据｜11 人日｜W1–W4

- [ ] 对照新 `eda.jobreport.v1` 与旧 `main/jobs/schemas/job-report.schema.json`，冻结 `edu.jobreport.v1` 映射表：`sim.build/sim.run/synth` 对旧 simulation/synthesis，旧 `errors[]` 对新 `diagnostics`，状态、退出码、原始码/行、产物、度量单位和缺失原因。
- [ ] 查真实插件输出：当前 CoreJobService 的 `diagnostics` 常为对象，只包含通用 error/timeout；必要时在官方 Yosys/Verilator provider 或 Adapter 中接现有解析器，填规范 `Diagnostic[]`，保留原始日志位置。不能把空 diagnostics 自动解释为“无问题”。
- [ ] 实现按具体 `job_id` 的 `JobReportView`，包含 origin(core/legacy)、raw_report_schema、completeness、revision/snapshot/input_fingerprint、plugin/version、artifact ID/hash；老记录缺指纹标 `legacy_unverified`。
- [ ] 不可用指标用 null+reason，不填 0；综合资源、时序按工具实际报告/器件/策略标 unit/source/availability。未知原始错误码保留 raw_code 和 `unclassified`，不能由 C++ 假定教学根因。
- [ ] 为 `GET /jobs/{j}/report` 与 `GET /artifacts/{a}`/受限内容读取接适配器；只读登记 artifact、报告/日志片段，不把整个 VCD 提供给模型。`last.json` 只作 legacy 输入发现，接口 ID 以 job_id/artifact_id 为准。
- [ ] 用真实 synth/仿真、旧任务 fixture 验证：锁存器、语法错误、警告、干净结果、未产生报告、解析失败、报告与源码版本不一致。原始报告与规范报告可相互追溯。

**修改点**：拟建 `main/agent/ReportAdapter.*`、旧 `main/jobs` 只读桥、官方插件解析器必要补充、`tests/agent/`。**输出给 U1/U2**：可机器验证的锁存器/干净/解析失败 JSON fixture。**完成条件**：规范报告不丢诊断来源与产物 hash；未知/不完整明确标识；SF-AC01。**依赖**：D-02，真实工具和旧报告样例。

### SF-07 局部设计映射与上下文查询｜9 人日｜W4–W6

- [ ] 定义 revision 限定的 node_id/source_ref；使用现有 SigTree uid 与 VerilogManager 关系，但不假定 uid 跨重启或所有编辑永久稳定。失败时返回 `mapping_status=unavailable/ambiguous/stale`。
- [ ] 在 UI 线程或受控数据线程提取不可变局部 DTO：选中元件/连线/RTL 片段、模块/信号/端口、相关源码行；HTTP worker 不直接遍历正在变化的 wx/SigTree 对象。
- [ ] 实现 `GET /projects/{p}/sources/{source_id}`、`GET /projects/{p}/design/nodes/{node_id}` 和 `POST /projects/{p}/context/query`；行列转换明确 1 基 Unicode code point 对编辑器字节列的映射。
- [ ] context/query 按 selection→诊断→局部源码→Job 摘要裁剪，强制 max_bytes、条数上限及 omitted/reason；多项数据同 revision，期间变更返回 409。
- [ ] 对图码同步新建/删除节点、跨文件同名模块、端口重命名、解析失败、旧卡定位做回归；无映射时只显示可信模块/源码，不能高亮猜测对象。

**修改点**：拟建 `main/agent/AgentContextBridge.*`、只读 DTO、现有 `SigTree/VerilogManager/CanvasPanel/SigTextEditor` 接线。**输出给 U1/U2/S3**：设计/源码 refs 与 unavailable fixture。**完成条件**：EDU-02 可点回真实对象；多线程重载/编辑无悬垂引用；SF-AC03/06。**依赖**：SF-05、SF-01。

### SF-08 波形 artifact 查询与精度｜10 人日｜W5–W7

- [ ] 将仿真 VCD/Wave artifact 与 `job_id/revision/snapshot` 绑定，验证文件 hash/可用性；signal_id 在 artifact 内有效，旧 artifact 删除后返回 410。
- [ ] 实现 `GET /waves/{a}/signals`，包含 full_name、width、timescale、分页/cursor；查询不提供任意本机路径。
- [ ] 实现 `POST /waves/{a}/query`：闭区间 `[start_tick,end_tick]`，每信号返回区间起点前的 `initial_value` 与区间内全部 transition；保留 x/z 或标记二态来源，返回 `exact/complete/next_cursor`。
- [ ] 单次最多 16 路、10,000 跳变、2 MiB；超限显式分页且不丢同 tick 多跳变。cursor 绑定 artifact/query hash/偏移；超时/取消不会把不完整结果伪装成 exact。
- [ ] 复用后台 `TraceQueryService`/`IWaveformBackend`，不把渲染缩略图或抽样曲线直接当精确分析数据；冷索引显示异步进度。
- [ ] 测试 64 位 tick、时间单位、空窗口、首跳变在边界、无前值、未知信号、VCD 大文件、分页续查、事件排序与 artifact 失效；记录基准环境，热索引限额内 p95 目标 <2 秒。

**修改点**：`main/trace/`、`include/eda/api/waveform.hpp` 的受控桥、拟建 Gateway WaveAdapter、测试。**输出给 U1/U2/S3**：复位异常的完整精确波形 fixture。**完成条件**：EDU-03 引用能复现同信号/时间窗，分页不丢值；SF-AC05。**依赖**：SF-05/06、真实 sim.run artifact。

## 5. S3：原生 UI、联动与发布（40 人日）

### SF-09 教学面板、状态与计划/提示卡｜14 人日｜W1–W5

- [ ] 做可用的面板状态/交互草图并与 U2 确认卡片数据契约：输入、上下文标签、进度、提示卡、计划卡、课程引用、历史入口、设置。布局为新增停靠面板，不改画布/代码/波形主流程。
- [ ] 接 `POST /sessions`、`POST /sessions/{s}/runs`、`GET /runs/{r}`、`GET /sessions/{s}/state/events`；提交立即有反馈，长任务异步处理，事件乱序按 state_version/状态快照纠正。
- [ ] 只渲染经 UCAgent 输出检查的 `TeachingCard` 和 `PlanCard`；UI 不写死教学规则。卡片显示 issue、版本、证据、课程引用、局限；旧版本卡片标明已过期。
- [ ] 实现“更多提示”、“申请参考解法”、“确认查看参考解法”、“放弃/取消”的独立动作与防重复点击。L4 第一步不含答案；第二步持有有效 challenge/receipt 才呈现；未检查的模型流不得提前显示。
- [ ] 实现计划审批：学生看见目标、每步能力/插件/参数、快照、最大 Job 数、停止条件；明确批准后由 SigFlow 签发 grant。计划修改、旧版本、过期/撤销均要求重新审批；不能由模型文本触发。
- [ ] 建立入口：菜单/报告诊断/右键选中对象的“询问助教”；无工程、dirty、Agent 未启动、无模型、工具未装、等待 Job、取消/失败、服务重启状态各有明确提示。
- [ ] 测试连续点击、切项目、关窗、提示卡过期、模型响应晚到；后台结果通过 `CallAfter`/弱引用或等效机制返回 UI，窗口销毁后不回调释放对象。

**修改点**：拟建 `main/agent/AgentPanel.*`/卡片、`MainFrame/MainMenuBar` 入口、GUI 辅助测试。**输出给 U1/U2**：卡片渲染 fixture、action/receipt 端到端录屏。**完成条件**：G0 Mock 卡片、G1 锁存器真实教学和 L4 两步、EDU-06 降级；SF-AC07/08。**依赖**：SF-01、U1 的 Mock Agent API；S1/S2 数据逐步接入。

### SF-10 四视图锚点与双向定位｜10 人日｜W5–W7

- [ ] 为 Agent 卡片建立统一 `EvidenceRef → UI Action` 解析器：源码定位、原理图节点高亮、波形信号/时间窗、报告诊断；所有定位校验 project/revision/artifact。
- [ ] 从原理图选中元件/线、RTL 选中范围、波形框选 A/B 和报告诊断创建结构化 selection refs，传给 run；只发送必要局部数据与锚点。
- [ ] 复用 `WaveformView::SetAB/JumpToTime/SetVisibleSignals` 等现有能力；时间 tick 与真实 artifact timescale 转换后再定位，避免显示错单位。
- [ ] 复用已有图码同步映射而不重写算法；综合优化或跨文件映射无可靠对应时降级到模块/源码，不制造高亮关系。
- [ ] 做原理图→RTL、RTL→原理图、诊断→代码/报告、波形→代码与卡片→波形回归；重新解析后的旧 node_id/旧 Job 提示过期。

**修改点**：拟建 EvidenceNavigator、现有 `CanvasPanel/SigTextEditor/WaveformView` 最小接线。**输出给 U2/U3**：可点回证据锚点示例。**完成条件**：EDU-02/03 四视图定位可靠，映射失败可理解；SF-AC06。**依赖**：SF-07/08/09。

### SF-11 学习历史、课程引用、主动提示与配置｜8 人日｜W6–W9

- [ ] 通过 U3 Agent API 展示本地 learner/profile 摘要、会话历史、课程引用来源/章节；引用 URL 来自结构化字段，用户明确点击才打开，失效链接显示来源和缓存信息。
- [ ] 提供记录导出与删除入口，调用 UCAgent API 并显示 purge 状态；切换 profile 清空 UI 会话缓存，不显示上一位学生历史。项目仓库不保存学生学习数据库。
- [ ] 应用级设置接 `agent.enabled`、`agent.auto_prompt=false`、profile/policy ID 与模型状态引用；教育版默认显示教学入口；关闭后现有编辑/工具不依赖 Python。
- [ ] 可关闭的主动提示只订阅新完成 Job；同 project/revision/job/issue 去重，非模态展示，有“静音/稍后”；失败 Job 不反复弹窗，页面关闭后不弹已陈旧提示。
- [ ] 如时间允许，资源对比仅对同目标、插件/版本/策略显示差值与单位；否则列为 P1 未做，不影响核心 G3。
- [ ] 与 U3 联调无模型/课程离线、历史删除、跨 profile、主动提示频率和关闭设置持久化。

**修改点**：`main/agent/` 视图/设置、`MainFrame` 事件入口；学习数据仍由 U3 服务持有。**输出给 U3**：API/UI 联调结果。**完成条件**：EDU-05 学习历史可查/删、课程可点开；主动提示默认关闭且可静音；SF-AC08。**依赖**：SF-09，U3 的 API。

### SF-12 GUI 回归、用户交付与试用整改｜8 人日｜W8–W10

- [ ] 制作按真实工具运行的演示脚本：锁存器 L1–L4/复测、计数器波形、计划执行与取消、无模型降级；记录项目 revision、Job ID、工具版本。
- [ ] 完整回归现有工程打开/保存、图码同步、仿真、综合、手动布线/打包/烧录、插件选择、WavePanel、TraceBridge；Agent disabled 状态必须保持既有工作流。
- [ ] 与 U1/U2/U3 验收 Windows/Linux/既有麒麟目标安装包，记录依赖、中文空格路径、多实例、升级/卸载后数据行为；修复阻塞问题。
- [ ] 配合教师/学生试用，记录可理解性、误点、历史/引用体验、卡顿与错误；按优先级整改，未验证教学效果在发布说明中明确标记。
- [ ] 编写学生使用指南、授课演示步骤、状态/故障说明、接口变更记录和已知限制；原 README/BUILD 中过时的构建叙述按实际发布矩阵修正。
- [ ] 形成 G4 验收包：测试结果、录屏、性能数据、目标 OS 清单、依赖/许可证、数据导出/删除验证、回滚步骤。

**修改点**：GUI/安装脚本、`docs/edu-agent/` 使用/发布材料、确有过时内容的构建文档。**完成条件**：EDU-01…06 与 SF-AC01…10 证据齐全，阻塞缺陷清零，已知限制公开；G4。**依赖**：全部 P0 与 UCAgent 可安装包。

## 6. 与 UCAgent 组的逐项交接

| 交接时间 | SigFlow 提供 | UCAgent 提供 | 联合检查/失败时替代物 |
|---|---|---|---|
| W1 D3 | Gateway schema 草案、真实项目/Job/报告 fixture、锁存器 RTL | Agent API 草案、锁存器教学卡草稿、UCAgent baseline 候选 | U1/S1 共同签契约；若真服务未就绪，双方用同 fixture Mock |
| W2 / G0 | health/capabilities/context/report 的 Mock 与最小真服务、版本/nonce 握手 | `/sessions`/`runs`/events 的 Mock 与可运行最小 sidecar | 双向调用和协议不匹配演示；任一侧 Mock 不可替代跨平台 sidecar spike |
| W3 | snapshot/source/真实 synth/job report、grant/receipt fixture | L1–L4 结构卡、策略/Checker、idempotency 客户端 | 冻结 issue/诊断编码与 source refs，解决格式分歧 |
| W4 / G1 | 真实锁存器新旧 revision、获批 synth、二次解锁 UI | 最小课程引用、历史记录、参考解法策略 | 端到端学生改 RTL→复测；只展示 Mock 文案不算通过 |
| W5 | 仿真 build/run 产物、波形信号/区间查询 | 波形教学、计划卡与 OutcomeChecker | 用同一个计数器 fixture 核对 timescale/expected waveform |
| W6 / G2 | 四视图锚点、取消/旧版本、完整精确波形 | 复测反馈与证据引用 | 真实工具与真实 GUI 联调，旧引用需可见降级 |
| W7–W8 / G3 | 恢复/主动提示/Beta 安装包、完整状态 UI | 8 类模式评测、≥20 课程片段、个性化/删除 | 双平台故障注入；无完成检验的模式不能列支持 |
| W9–W10 / G4 | 安装/GUI 回归/演示与发布材料 | 真实模型回归/教师评审/试用结论 | 联合签收发布矩阵与已知限制 |

跨组依赖用真实交付物签收：schema commit/fixture、服务构建/运行命令、结果日志、相关测试。沟通节奏：每周两次联调、每周一次真实端到端演示；改字段当日通知 S1/U1，破坏性变更须版本处理。

## 7. 两周 Gate 与逐周检查点

### W1–W2：G0 接通

- [ ] W1 D1–D2：D-01 基线、两套实验样例和现有测试结果归档。
- [ ] W1 D3：D-02 schema 草案、U1/S1 Mock 双向联通；D-03 教育能力白名单冻结。
- [ ] W1 D4–D5：sidecar Windows/Linux 最小联通，报告 fixture 归一化样本，面板交互草图。
- [ ] W2：协议 v1 最小字段冻结；health/capabilities/context/report、会话/卡片 Mock、版本失败路径通过。
- [ ] G0 签收：两个 OS 能启动最小 sidecar；无模型时“选择工程→读报告→显示规则卡片”；双方同一契约测试；缺能力、协议不兼容均有用户可读反馈。

### W3–W4：G1 教学 MVP

- [ ] W3：snapshot/revision、真实 synth、锁存器诊断、grant 与 L4 receipt 测试形成单项可演示片段。
- [ ] W4：UI 展示 L1–L4，用户自行修复并保存，审批后新 Job 复测；新旧报告引用与记录齐全。
- [ ] G1 签收：真实 Yosys 正例/合法反例；锁存器 L1–L3 无完整解法，L4 两步；未授权/旧版本执行拒绝；无 Key 可降级。

### W5–W6：G2 证据闭环

- [ ] W5：sim.build/run、artifact 归属、精确波形查询与局部设计映射联通。
- [ ] W6：计数器复位实验从波形选择→解释→学生修改→复测；四视图引用可点回；取消与版本过期路径通过。
- [ ] G2 签收：同一 snapshot 的仿真/综合结果关联，波形 tick/初值/分页可信；旧报告不当作新代码证据。

### W7–W8：G3 Beta

- [ ] W7：事件重放/游标过期、sidecar 崩溃恢复、双实例/跨项目隔离与安装 Beta。
- [ ] W8：8 类教学模式的 SigFlow 数据支持范围逐项标注；学习历史/引用/删除 UI；主动提示默认关闭；联合故障测试通过。
- [ ] G3 签收：每类模式均有真实可支持/不支持说明；重复提交不重跑；Beta 安装与基本性能达标。若部分检测器缺失，由 U2 的证据不足规则表达，不在 SigFlow 构造假诊断。

### W9–W10：G4 发布

- [ ] W9：真实模型/真实工具/GUI 三层证据、教师试用、目标 OS 清单与性能测量。
- [ ] W10：阻塞缺陷修复，发布包/手册/回滚与已知限制签收。
- [ ] G4 签收：EDU-01…06、SF-AC01…10 逐项有证据，Agent 关闭时旧工作流回归通过。

**Gate 失败规则**：保留未完成任务状态，记录缺口/预计修复周。不能用契约 Mock 替代真实工具通过，也不能用真实工具通过代替教学评审。W6 若进度超预算，先后置资源对比、主动提示和映射覆盖扩展；鉴权、版本、幂等、取消、报告真实性与故障可见性不可降级。

## 8. 测试与验收矩阵

| 测试集/场景 | 责任 | 自动/手动 | 判定与需留证据 |
|---|---|---|---|
| v1 schema 与双方 golden fixtures | S1/U1 | 自动 | 正常/错误/未知字段/超限/中文编码；双方 CI 结果一致 |
| 身份与路径边界 | S1/S2 | 自动 | 非 loopback、坏 token、伪 Origin、跨项目、`..`/符号链接越界全拒绝 |
| grant/receipt/幂等 | S1/S3/U1 | 自动 + GUI | 20 次并发重复仅 1 Job；参数冲突 409；假确认/重放被拒绝；L4 双击不越级 |
| 快照/过期/并发编辑 | S2 | 自动 + GUI | dirty 拒绝执行，快照后修改不改变 Job 输入，混合版本不出现 |
| 新旧报告与诊断 | S2/U2 | 自动 + 真工具 | 原始码、来源、严重度、产物哈希不丢；解析不全与 clean 明确区分 |
| Job 取消/超时/重启 | S1 | Fake provider + 真工具 | 子进程停止或明确失败，重启不自动重跑，取消只影响本 run |
| 波形精度与分页 | S2/U2 | 自动 + GUI | 首值/边界/xz/64 位 tick/同 tick 多跳变无丢失，证据不足标记 |
| 四视图锚点 | S2/S3 | GUI 脚本 | 原理图/RTL/波形/报告可跳回；无法映射无错误高亮 |
| UI 异步与降级 | S3 | 手动 + 故障注入 | 关窗不崩溃，Agent 断开可重连，无 Key/协议不符显示清楚，旧 IDE 可用 |
| 现有产品回归 | S3/S1 | CTest + GUI | 图码同步、插件选择、Job、波形、TraceBridge、手动 FPGA 流程按改动影响面通过 |
| Windows/Linux/既有麒麟目标 | S1/S3/U1 | 真机或目标环境 | OS/版本/架构、构建/安装命令、工具/sidecar 版本与结论留档 |

建议测试入口：现有 `tests/contract/`、`tests/plugins/`、`tests/ir/` 的 CTest 保持；新 `tests/agent/` 与两服务各跑 schema fixture。W1 确定真实构建目录后将命令写入 `baseline.md` 和 CI。基准机器与工程规模按 spec §8 固定，报告 p95 与样本量，不能引用历史测试结果作新功能通过证据。

### 8.1 六条用户旅程的最小验收证据

| 旅程 | SigFlow 侧必须出示 |
|---|---|
| EDU-01 锁存器 | 原始/规范报告、RTL SourceRef、旧/新 revision、两个 Job ID、L4 UI 动作凭据、录屏 |
| EDU-02 图码 | node/source refs、原理图→代码与卡片→节点跳转、无映射降级画面 |
| EDU-03 波形 | waveform artifact hash、timescale、查询参数/结果、A/B 时间窗与代码锚点 |
| EDU-04 计划 | 审批卡、grant scope/plan hash、Job 状态链、取消和失败停止记录 |
| EDU-05 个性化 | 历史/课程引用 UI、profile 切换、导出/删除状态；学习推理证据由 U3 提供 |
| EDU-06 故障 | 无 Key、Agent 退出/重启、协议不兼容、EDA 工具缺失四种状态演示；旧流程回归 |

## 9. 发布完成定义与风险追踪

### 9.1 SigFlow 组完成定义

- [ ] v1 契约、fixtures、SDK/Mock 示例与变更记录可供 UCAgent 组独立开发。
- [ ] C++ Gateway 对项目、RTL、报告、波形、插件状态与有界 Job 执行提供受控 HTTP 能力；真实工具使用现有插件/JobService。
- [ ] 原生面板能显示已检查的教学结果，完成计划审批、分级提示操作、课程/历史入口和四视图证据定位。
- [ ] Job、快照、授权、审计的 idempotency/revision/恢复逻辑通过负例；Agent 崩溃或无模型时旧 IDE 功能可用。
- [ ] 两平台与团队已有目标麒麟环境按发布清单验证，安装/回滚/排障材料齐全。
- [ ] SF-AC01…10 与 EDU-01…06 的验收证据归档；未完成 P1 和已知限制明确列出。

### 9.2 风险与触发动作

| 信号 | 立即动作 | 责任 |
|---|---|---|
| W2 后 UCAgent Windows sidecar 仍无法最小运行 | 保留 Mock 联调，U1/S1 出原生兼容阻塞分析与替代方案评审；不声称 Windows 发布通过 | S1/U1 |
| 真实综合报告无可定位锁存器诊断 | S2 补解析适配、保存原始日志与行号；U2 暂用证据不足卡片 | S2/U2 |
| 存储崩溃窗口可能重复 Job | 暂停 Agent 写路径，先补幂等/恢复测试与原子记录，再继续计划调度 | S1 |
| SigTree 映射不稳 | 先交源码/报告定位，图形定位明确 unavailable；不阻塞锁存器 G1 | S2/S3 |
| 大 VCD 查询造成 UI 卡顿 | 限额/后台分页，缩小选择窗；不把可视化抽样结果冒充精确证据 | S2 |
| 课程/历史 API 推迟 | S3 用契约 Mock 完成结构 UI，G1/G3 真实数据验收不免除 | S3/U3 |
| 10 周容量不足 | 先后置 P1；双方更新 Gate、发布清单与剩余工作，不取消基础信任与数据正确性门槛 | S1/S2/S3 |

本清单仅对 SigFlow 组工作计 120 计划人日。UCAgent 组的教学规则、RAG、学习数据库、模型评测由其 [spec](../ucagent/spec.md) 管理；SigFlow 组在约定 Gate 提供可复现数据与接口，并共同签收完整教育体验。
